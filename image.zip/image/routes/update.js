const router=require('express').Router();
const User=require('../models/User');
const jwt=require('jsonwebtoken');
const { verifyToken, verifyTokenAndAuthorization } = require('./verifyToken');

router.post('/:id/:photoId',verifyTokenAndAuthorization,async (req,res)=>{
    try{
    const user=await User.findById(req.params.id);
    if(user)
    {
        try{
            
            const updatedUser=await User.findByIdAndUpdate(req.params.id,{ 
                "$set": {[`pictures.$[outer]`]:req.body}
            },{ 
                "arrayFilters": [{ "outer.id": req.params.photoId }],"new": true
            });
            
            res.status(200).json(updatedUser);
        }catch(err){
            res.status(400).send({message:"Error in updating"});
        }
    }
    else
    {
        res.status(404).send('User Not Found');
    }
    }catch(err){
        res.status(400).send(err);
    }
})

module.exports=router;